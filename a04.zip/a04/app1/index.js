const express = require("express");
const PORT = 5000;

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.send("Hello from Express!");
});

app.listen(PORT, () => console.log(`Server started on ${PORT}`));

app.get("/headers", (req, res) => {
  res.send(req.headers);
});

app.get("/body", (req, res) => {
  res.send(req.body);
});

// form data
app.post("/contact", (req, res) => {
  if (!req.body.name) {
    return res.status(400).send("Name is required");
  }

  // DB staff
  res.status(201).send(`Thank you ${req.body.name}`);
});

// simulate login
app.post("/login", (req, res) => {
  if (!req.header("x-auth-token")) {
    return res.status(400).send("No Token");
  }

  if (req.header("x-auth-token") !== "123456") {
    return res.status(401).send("Not authorized");
  }

  res.send("Logged in");
});

app.put("/items/:id", (req, res) => {
  // Database stuff

  res.json({
    id: req.params.id,
    title: req.body.title,
  });
});

app.delete("/items/:id", (req, res) => {
  // Database stuff

  res.json({ msg: `Post ${req.params.id} deleted` });
});
